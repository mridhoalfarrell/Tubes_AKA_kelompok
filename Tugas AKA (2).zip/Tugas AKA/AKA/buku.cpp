#include <iostream>
#include "buku.h"
#include <cstdlib>

using namespace std;


void createlist(listBuku &b){
    b.first = NULL;
    b.last = NULL;
}

adrBuku createElmBuku(string judul, string penulis, string kategori, int pinjam){
    adrBuku p = new elmBuku;

    p->info.Judul = judul;
    p->info.penulis = penulis;
    p->info.kategori = kategori;
    p->info.totalpinjam = pinjam;

    return p;
}

bool isEmpty(listBuku b){
    return b.first == NULL && b.last == NULL;
}

void inserLast(listBuku &b, adrBuku p){
    if (isEmpty(b)){
        b.first = p;
        b.last = p;
    }else {
        p->prev = b.last;
        b.last->next = p;
        b.last = p;
    }
}

adrBuku findbook(listBuku b, string judul){
    adrBuku p;
    p = b.first;
    while(p->info.Judul != judul && p != NULL){
        p = p->next;
    }
    if(p != NULL){
        return p;
    }else {
        return NULL;
    }
}

adrBuku mostBorrowedRecursiveCategory(adrBuku current, adrBuku maxBook, const string& category){
    if (current == nullptr) {
        return maxBook;
    }
    if (current->info.kategori == category) {
        if (maxBook == nullptr || current->info.totalpinjam > maxBook->info.totalpinjam) {
            maxBook = current;
        }
    }
    return mostBorrowedRecursiveCategory(current->next, maxBook, category);
}

adrBuku mostBorrowedIterativeCategory(adrBuku first, const string& category){
    adrBuku maxBook = nullptr;
    adrBuku current = first;

    while (current != nullptr) {
        if (current->info.kategori == category) {
            if (maxBook == nullptr || current->info.totalpinjam > maxBook->info.totalpinjam) {
                maxBook = current;
            }
        }
        current = current->next;
    }

    return maxBook;
}

adrBuku mostBorrowedRecursivePenulis(adrBuku p, adrBuku maxBook, string &Penulis){
    if (p == NULL) {
        return maxBook;
    }
    if (p->info.penulis == Penulis) {
        if (maxBook == NULL || p->info.totalpinjam > maxBook->info.totalpinjam) {
            maxBook = p;
        }
    }
    return mostBorrowedRecursivePenulis(p->next, maxBook, Penulis);
}

adrBuku mostBorrowedIterativePenulis(adrBuku first, string &Penulis){
    adrBuku maxBook = NULL;
    adrBuku P = first;

    while (P != NULL) {
        if (P->info.penulis == Penulis) {
            if (maxBook == NULL || P->info.totalpinjam > maxBook->info.totalpinjam) {
                maxBook = P;
            }
        }
        P = P->next;
    }

    return maxBook;
}


adrBuku mostBorrowedRecursivePeminjam(adrBuku P, adrBuku maxBook, int &Peminjam){
    if (P == NULL) {
        return maxBook;
    }
    if (P->info.totalpinjam >= Peminjam) {
        if (maxBook == NULL || P->info.totalpinjam - Peminjam < maxBook->info.totalpinjam - Peminjam) {
            maxBook = P;
        }
    }
    return mostBorrowedRecursivePeminjam(P->next, maxBook, Peminjam);
}

adrBuku mostBorrowedIterativePeminjam(adrBuku first, int &Peminjam){
    adrBuku maxBook = NULL;
    adrBuku P = first;

    while (P != NULL) {
        if (P->info.totalpinjam >= Peminjam) {
            if (maxBook == NULL || P->info.totalpinjam - Peminjam < maxBook->info.totalpinjam - Peminjam) {
                maxBook = P;
            }
        }
        P = P->next;
    }

    return maxBook;
}


void printAllCategoryBook(listBuku b, string kategori){
    adrBuku current = b.first;
    bool found = false;

    while (current != nullptr) {
        if (current->info.kategori == kategori) {
            if (!found) {
                cout << "Buku-buku dalam kategori '" << kategori << "':" << endl;
                found = true;
            }

            cout << "Judul Buku   : " << current->info.Judul << endl;
            cout << "Penulis      : " << current->info.penulis << endl;
            cout << "Total Pinjam : " << current->info.totalpinjam << " kali" << endl;
            cout << "----------------------------" << endl;
        }
        current = current->next;
    }

    if (!found) {
        cout << "Tidak ada buku dalam kategori '" << kategori << "'." << endl;
    }
}

void printOneDataBook(listBuku b, adrBuku p){
    if (p == nullptr) {
        cout << "Buku tidak ditemukan." << endl;
        return;
    }

    cout << "Judul Buku   : " << p->info.Judul << endl;
    cout << "Penulis      : " << p->info.penulis << endl;
    cout << "Kategori     : " << p->info.kategori << endl;
    cout << "Total Pinjam : " << p->info.totalpinjam << " kali" << endl;
}

void Menu(){
    cout << "----------------------------------------" << endl;
    cout << "            MENU PERPUSTAKAAN           " << endl;
    cout << "----------------------------------------\n" << endl;
    cout << "Tabah Buku (1)  " << endl;
    cout << "Cari Buku  (2) " << endl;
    cout << "Cari Buku Terbaik (Rekursif) (3)  " << endl;
    cout << "Cari Buku Terbaik (Iteratif) (4)  " << endl;
    cout << "Tampilkan Semua Buku Berdasarkan Kategori (5)  " << endl;
    cout << "Exit (6)  " << endl;
}

void ClearScreen(){
    system("cls");
}

void pilihan3(){
    cout << "Anda ingin mencari buku berdasarkan apa ? " << endl;
    cout << "1. Kategori " << endl;
    cout << "2. Penulis " << endl;
    cout << "3. Banyak dipinjam " << endl;
}

void pilihan4(){
    cout << "Anda ingin mencari buku berdasarkan apa ? " << endl;
    cout << "1. Kategori " << endl;
    cout << "2. Penulis " << endl;
    cout << "3. Banyak dipinjam " << endl;
}

