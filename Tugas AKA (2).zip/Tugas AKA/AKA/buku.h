#ifndef BUKU_H_INCLUDED
#define BUKU_H_INCLUDED
#include <iostream>
#include <cstdlib>

using namespace std;

typedef struct Buku infotype;
typedef struct elmBuku *adrBuku;

struct Buku{
    string Judul;
    string penulis;
    string kategori;
    int totalpinjam;
};

struct elmBuku{
    infotype info;
    adrBuku next;
    adrBuku prev;
};

struct listBuku {
    adrBuku first;
    adrBuku last;
};

void createlist(listBuku &b);
adrBuku createElmBuku(string judul, string penulis, string kategori, int pinjam);
bool isEmpty(listBuku b);
void inserLast(listBuku &b, adrBuku p);
adrBuku findbook(listBuku b, string judul);

adrBuku mostBorrowedRecursiveCategory(adrBuku current, adrBuku maxBook, const string& category);
adrBuku mostBorrowedIterativeCategory(adrBuku first, const string& category);

adrBuku mostBorrowedRecursivePenulis(adrBuku p, adrBuku maxBook, string &Penulis);
adrBuku mostBorrowedIterativePenulis(adrBuku first, string &Penulis);

adrBuku mostBorrowedRecursivePeminjam(adrBuku P, adrBuku maxBook, int &Peminjam);
adrBuku mostBorrowedIterativePeminjam(adrBuku first, int &Peminjam);

void printAllCategoryBook(listBuku b, string kategori);
void printOneDataBook(listBuku b, adrBuku p);

void Menu();
void ClearScreen();
void pilihan3();
void pilihan4();

#endif // BUKU_H_INCLUDED
