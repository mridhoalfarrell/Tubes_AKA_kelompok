#include <iostream>
#include "buku.h"
#include <cstdlib>

using namespace std;

int main() {
    int a = -1;
    int peminjam;
    listBuku B;
    createlist(B);
    while (a != 6){
        ClearScreen();
        Menu();
        cout << "Masukan Pilihan Anda : ";
        cin >> a;
        if(a == 1){
            string judul,penulis,kategori;
            cout << "Masukan Judul Buku : ";
            cin.ignore();
            getline(cin, judul);
            cout << "Masukan Penulis Buku : ";
            cin.ignore();
            getline(cin, penulis);
            cout << "Masukan Kategori Buku : ";
            cin.ignore();
            getline(cin, kategori);
            cout << "Masukan Total Dipinjam : ";
            cin >> peminjam;

            adrBuku newBook = createElmBuku(judul,penulis,kategori,peminjam);
            inserLast(B, newBook);
            cout << "Buku berhasil ditambahkan" << endl;

            cout << "Tekan Enter untuk kembali ke menu utama ";
            cin.ignore();
            cin.get();

        }else if(a == 2){
            string judul;
            cout << "Masukan Judul Buku Yang Ingin Anda Cari: ";
            cin.ignore();
            getline(cin, judul);

            adrBuku Found = findbook(B, judul);
            printOneDataBook(B, Found);

            cout << "Tekan Enter untuk kembali ke menu utama ";
            cin.ignore();
            cin.get();

        }else if(a == 3){
            int i;
            adrBuku Q;
            pilihan3();
            if(i == 1){
                string kategori;
                cout << "Kategori-Kategori Dalam Perpustakaan: \n";
                cout << "Fiksi";
                cout << "NonFiksi";
                cout << "Sejarah";
                cout << "Pendidikan";
                cout << "Agama\n";
                cout << "Tolong Masukan Kategori Sesuai dengan yang ada di atas! \n" << endl;
                cout << "Masukan kategori buku yang anda inginkan : ";
                cin.ignore();
                getline(cin,kategori);
                adrBuku P = mostBorrowedRecursiveCategory(P,Q,kategori);
                printOneDataBook(B,P);
            }else if(i == 2){
                string penulis;
                cout << "Masukan Nama Penulis Buku: ";
                cin.ignore();
                getline(cin,penulis);
                adrBuku P = mostBorrowedRecursivePenulis(P, Q, penulis);
                printOneDataBook(B, P);
            }else if(i == 3){
                int lower;
                cout << "Masukan Berapa Minimal Peminjaman Buku yang anda cari: ";
                cin >> lower;
                adrBuku P = mostBorrowedRecursivePeminjam(P, Q, lower);
                printOneDataBook(B, P);
            }else {
                cout << "Pilihan Yang Anda Ajukan Tidak Ada!!" << endl;
            }

            cout << "Tekan Enter untuk kembali ke menu utama ";
            cin.ignore();
            cin.get();

        }else if(a == 4){
            int i;
            adrBuku F;
            pilihan4();
            if(i == 1){
                string kategori;
                cout << "Kategori-Kategori Dalam Perpustakaan: \n";
                cout << "Fiksi";
                cout << "NonFiksi";
                cout << "Sejarah";
                cout << "Pendidikan";
                cout << "Agama\n";
                cout << "Tolong Masukan Kategori Sesuai dengan yang ada di atas! \n" << endl;
                cout << "Masukan kategori buku yang anda inginkan : ";
                cin.ignore();
                getline(cin,kategori);
                adrBuku P = mostBorrowedIterativeCategory(F,kategori);
                printOneDataBook(B,P);
            }else if(i == 2){
                string penulis;
                cout << "Masukan Nama Penulis Buku: ";
                cin.ignore();
                getline(cin,penulis);
                adrBuku P = mostBorrowedIterativePenulis(F, penulis);
                printOneDataBook(B, P);
            }else if(i == 3){
                int lower;
                cout << "Masukan Berapa Minimal Peminjaman Buku yang anda cari: ";
                cin >> lower;
                adrBuku P = mostBorrowedIterativePeminjam(F, lower);
                printOneDataBook(B, P);
            }else {
                cout << "Pilihan Yang Anda Ajukan Tidak Ada!!" << endl;
            }

            cout << "Tekan Enter untuk kembali ke menu utama ";
            cin.ignore();
            cin.get();

        }else if(a == 5){
            string kategori;
            cout << "Kategori-Kategori Dalam Perpustakaan: \n";
            cout << "Fiksi";
            cout << "NonFiksi";
            cout << "Sejarah";
            cout << "Pendidikan";
            cout << "Agama\n";
            cout << "Tolong Masukan Kategori Sesuai dengan yang ada di atas! \n" << endl;
            cout << "Masukan kategori yang anda inginkan : ";
            cin.ignore();
            getline(cin,kategori);
            printAllCategoryBook(B,kategori);

            cout << "Tekan Enter untuk kembali ke menu utama ";
            cin.ignore();
            cin.get();
        }else if(a == 6){
            break;
        }else {
            cout << "Pilihan Tidak Valid!! " << endl;

            cout << "Tekan Enter untuk kembali ke menu utama ";
            cin.ignore();
            cin.get();
        }

    }
    return 0;
}
